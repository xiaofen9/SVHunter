var searchData=
[
  ['transport',['transport',['../classnetconf_1_1_session.html#a5a45e8fb7e1c3415e2b59b6437c832f4',1,'netconf::Session']]],
  ['transport_5fssh',['TRANSPORT_SSH',['../namespacenetconf.html#a70c5be7db4485a438c4ee29c0d101ae3',1,'netconf']]],
  ['transport_5ftls',['TRANSPORT_TLS',['../namespacenetconf.html#aed399343c48d2edb26f35191a44751f1',1,'netconf']]]
];
