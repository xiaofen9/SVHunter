var searchData=
[
  ['candidate',['CANDIDATE',['../namespacenetconf.html#a32542093882c25b0830f06cae1ee2256',1,'netconf']]],
  ['capabilities',['capabilities',['../classnetconf_1_1_session.html#a52fe932b48b649e02ac5d089750df3bc',1,'netconf::Session']]]
];
