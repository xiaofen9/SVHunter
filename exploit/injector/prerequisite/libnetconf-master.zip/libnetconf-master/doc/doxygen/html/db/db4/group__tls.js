var group__tls =
[
    [ "nc_tls_destroy", "db/db4/group__tls.html#gacf3aed5cccac55d0548f46761707ece9", null ],
    [ "nc_tls_init", "db/db4/group__tls.html#gacbf946a826fa6c7c18a4e66d532b659f", null ]
];