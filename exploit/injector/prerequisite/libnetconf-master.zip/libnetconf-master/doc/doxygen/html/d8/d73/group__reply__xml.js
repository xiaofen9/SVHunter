var group__reply__xml =
[
    [ "ncxml_reply_build", "d8/d73/group__reply__xml.html#gaaaf53b5a839be6935059fdf2818a5a42", null ],
    [ "ncxml_reply_data", "d8/d73/group__reply__xml.html#ga1ce60f5416d4f75586836c1429c37149", null ],
    [ "ncxml_reply_data_ns", "d8/d73/group__reply__xml.html#ga3647f5a4bb6d8827a613a6b214d45581", null ],
    [ "ncxml_reply_dump", "d8/d73/group__reply__xml.html#ga68ec8a0daf54f584339924bca5b5a682", null ],
    [ "ncxml_reply_get_data", "d8/d73/group__reply__xml.html#ga7878bc6bc6b6d1ca002044d7edf85943", null ]
];