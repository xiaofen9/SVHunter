var annotated =
[
    [ "clbk", "d0/dd1/structclbk.html", "d0/dd1/structclbk" ],
    [ "ncds_custom_funcs", "d0/d28/structncds__custom__funcs.html", "d0/d28/structncds__custom__funcs" ],
    [ "ns_pair", "d0/d77/structns__pair.html", "d0/d77/structns__pair" ],
    [ "transapi", "d9/dc0/structtransapi.html", "d9/dc0/structtransapi" ],
    [ "transapi_data_callbacks", "d6/dcb/structtransapi__data__callbacks.html", "d6/dcb/structtransapi__data__callbacks" ],
    [ "transapi_file_callbacks", "de/df8/structtransapi__file__callbacks.html", "de/df8/structtransapi__file__callbacks" ],
    [ "transapi_rpc_callbacks", "d0/df8/structtransapi__rpc__callbacks.html", "d0/df8/structtransapi__rpc__callbacks" ]
];